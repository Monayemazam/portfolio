import type { Auth } from '@/types/auth';

declare module 'react' {
    interface InputHTMLAttributes<T> {
        passwordrules?: string;
    }
}

declare module '@inertiajs/core' {
    export interface InertiaConfig {
        sharedPageProps: {
            name: string;
            auth: Auth;
            flash?: {
                success?: string | null;
                error?: string | null;
                info?: string | null;
            };
            sidebarOpen: boolean;
            [key: string]: unknown;
        };
    }
}
