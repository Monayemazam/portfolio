import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AboutController::index
 * @see app/Http/Controllers/Admin/AboutController.php:21
 * @route '/admin/about'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/about',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AboutController::index
 * @see app/Http/Controllers/Admin/AboutController.php:21
 * @route '/admin/about'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AboutController::index
 * @see app/Http/Controllers/Admin/AboutController.php:21
 * @route '/admin/about'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AboutController::index
 * @see app/Http/Controllers/Admin/AboutController.php:21
 * @route '/admin/about'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AboutController::index
 * @see app/Http/Controllers/Admin/AboutController.php:21
 * @route '/admin/about'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AboutController::index
 * @see app/Http/Controllers/Admin/AboutController.php:21
 * @route '/admin/about'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AboutController::index
 * @see app/Http/Controllers/Admin/AboutController.php:21
 * @route '/admin/about'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\AboutController::updateContent
 * @see app/Http/Controllers/Admin/AboutController.php:48
 * @route '/admin/about'
 */
export const updateContent = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateContent.url(options),
    method: 'put',
})

updateContent.definition = {
    methods: ["put"],
    url: '/admin/about',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\AboutController::updateContent
 * @see app/Http/Controllers/Admin/AboutController.php:48
 * @route '/admin/about'
 */
updateContent.url = (options?: RouteQueryOptions) => {
    return updateContent.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AboutController::updateContent
 * @see app/Http/Controllers/Admin/AboutController.php:48
 * @route '/admin/about'
 */
updateContent.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateContent.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\AboutController::updateContent
 * @see app/Http/Controllers/Admin/AboutController.php:48
 * @route '/admin/about'
 */
    const updateContentForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateContent.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AboutController::updateContent
 * @see app/Http/Controllers/Admin/AboutController.php:48
 * @route '/admin/about'
 */
        updateContentForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateContent.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateContent.form = updateContentForm
/**
* @see \App\Http\Controllers\Admin\AboutController::storeFact
 * @see app/Http/Controllers/Admin/AboutController.php:60
 * @route '/admin/about/facts'
 */
export const storeFact = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeFact.url(options),
    method: 'post',
})

storeFact.definition = {
    methods: ["post"],
    url: '/admin/about/facts',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AboutController::storeFact
 * @see app/Http/Controllers/Admin/AboutController.php:60
 * @route '/admin/about/facts'
 */
storeFact.url = (options?: RouteQueryOptions) => {
    return storeFact.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AboutController::storeFact
 * @see app/Http/Controllers/Admin/AboutController.php:60
 * @route '/admin/about/facts'
 */
storeFact.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeFact.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AboutController::storeFact
 * @see app/Http/Controllers/Admin/AboutController.php:60
 * @route '/admin/about/facts'
 */
    const storeFactForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeFact.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AboutController::storeFact
 * @see app/Http/Controllers/Admin/AboutController.php:60
 * @route '/admin/about/facts'
 */
        storeFactForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeFact.url(options),
            method: 'post',
        })
    
    storeFact.form = storeFactForm
/**
* @see \App\Http\Controllers\Admin\AboutController::updateFact
 * @see app/Http/Controllers/Admin/AboutController.php:79
 * @route '/admin/about/facts/{fact}'
 */
export const updateFact = (args: { fact: number | { id: number } } | [fact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateFact.url(args, options),
    method: 'put',
})

updateFact.definition = {
    methods: ["put"],
    url: '/admin/about/facts/{fact}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\AboutController::updateFact
 * @see app/Http/Controllers/Admin/AboutController.php:79
 * @route '/admin/about/facts/{fact}'
 */
updateFact.url = (args: { fact: number | { id: number } } | [fact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fact: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fact: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fact: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fact: typeof args.fact === 'object'
                ? args.fact.id
                : args.fact,
                }

    return updateFact.definition.url
            .replace('{fact}', parsedArgs.fact.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AboutController::updateFact
 * @see app/Http/Controllers/Admin/AboutController.php:79
 * @route '/admin/about/facts/{fact}'
 */
updateFact.put = (args: { fact: number | { id: number } } | [fact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateFact.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\AboutController::updateFact
 * @see app/Http/Controllers/Admin/AboutController.php:79
 * @route '/admin/about/facts/{fact}'
 */
    const updateFactForm = (args: { fact: number | { id: number } } | [fact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateFact.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AboutController::updateFact
 * @see app/Http/Controllers/Admin/AboutController.php:79
 * @route '/admin/about/facts/{fact}'
 */
        updateFactForm.put = (args: { fact: number | { id: number } } | [fact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateFact.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateFact.form = updateFactForm
/**
* @see \App\Http\Controllers\Admin\AboutController::destroyFact
 * @see app/Http/Controllers/Admin/AboutController.php:90
 * @route '/admin/about/facts/{fact}'
 */
export const destroyFact = (args: { fact: number | { id: number } } | [fact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyFact.url(args, options),
    method: 'delete',
})

destroyFact.definition = {
    methods: ["delete"],
    url: '/admin/about/facts/{fact}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\AboutController::destroyFact
 * @see app/Http/Controllers/Admin/AboutController.php:90
 * @route '/admin/about/facts/{fact}'
 */
destroyFact.url = (args: { fact: number | { id: number } } | [fact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fact: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fact: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fact: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fact: typeof args.fact === 'object'
                ? args.fact.id
                : args.fact,
                }

    return destroyFact.definition.url
            .replace('{fact}', parsedArgs.fact.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AboutController::destroyFact
 * @see app/Http/Controllers/Admin/AboutController.php:90
 * @route '/admin/about/facts/{fact}'
 */
destroyFact.delete = (args: { fact: number | { id: number } } | [fact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyFact.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\AboutController::destroyFact
 * @see app/Http/Controllers/Admin/AboutController.php:90
 * @route '/admin/about/facts/{fact}'
 */
    const destroyFactForm = (args: { fact: number | { id: number } } | [fact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyFact.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AboutController::destroyFact
 * @see app/Http/Controllers/Admin/AboutController.php:90
 * @route '/admin/about/facts/{fact}'
 */
        destroyFactForm.delete = (args: { fact: number | { id: number } } | [fact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyFact.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyFact.form = destroyFactForm
/**
* @see \App\Http\Controllers\Admin\AboutController::reorderFacts
 * @see app/Http/Controllers/Admin/AboutController.php:101
 * @route '/admin/about/facts/reorder'
 */
export const reorderFacts = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorderFacts.url(options),
    method: 'post',
})

reorderFacts.definition = {
    methods: ["post"],
    url: '/admin/about/facts/reorder',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AboutController::reorderFacts
 * @see app/Http/Controllers/Admin/AboutController.php:101
 * @route '/admin/about/facts/reorder'
 */
reorderFacts.url = (options?: RouteQueryOptions) => {
    return reorderFacts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AboutController::reorderFacts
 * @see app/Http/Controllers/Admin/AboutController.php:101
 * @route '/admin/about/facts/reorder'
 */
reorderFacts.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorderFacts.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AboutController::reorderFacts
 * @see app/Http/Controllers/Admin/AboutController.php:101
 * @route '/admin/about/facts/reorder'
 */
    const reorderFactsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reorderFacts.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AboutController::reorderFacts
 * @see app/Http/Controllers/Admin/AboutController.php:101
 * @route '/admin/about/facts/reorder'
 */
        reorderFactsForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reorderFacts.url(options),
            method: 'post',
        })
    
    reorderFacts.form = reorderFactsForm
const AboutController = { index, updateContent, storeFact, updateFact, destroyFact, reorderFacts }

export default AboutController