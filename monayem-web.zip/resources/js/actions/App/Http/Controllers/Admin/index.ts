import DashboardController from './DashboardController'
import MediaController from './MediaController'
import SettingController from './SettingController'
import SectionController from './SectionController'
import HeroController from './HeroController'
import AboutController from './AboutController'
import SkillController from './SkillController'
import ProjectController from './ProjectController'
import ServiceController from './ServiceController'
import ExperienceController from './ExperienceController'
import ProcessStepController from './ProcessStepController'
import TestimonialController from './TestimonialController'
import SeoController from './SeoController'
import MessageController from './MessageController'
const Admin = {
    DashboardController: Object.assign(DashboardController, DashboardController),
MediaController: Object.assign(MediaController, MediaController),
SettingController: Object.assign(SettingController, SettingController),
SectionController: Object.assign(SectionController, SectionController),
HeroController: Object.assign(HeroController, HeroController),
AboutController: Object.assign(AboutController, AboutController),
SkillController: Object.assign(SkillController, SkillController),
ProjectController: Object.assign(ProjectController, ProjectController),
ServiceController: Object.assign(ServiceController, ServiceController),
ExperienceController: Object.assign(ExperienceController, ExperienceController),
ProcessStepController: Object.assign(ProcessStepController, ProcessStepController),
TestimonialController: Object.assign(TestimonialController, TestimonialController),
SeoController: Object.assign(SeoController, SeoController),
MessageController: Object.assign(MessageController, MessageController),
}

export default Admin