import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\HeroController::index
 * @see app/Http/Controllers/Admin/HeroController.php:19
 * @route '/admin/hero'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/hero',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\HeroController::index
 * @see app/Http/Controllers/Admin/HeroController.php:19
 * @route '/admin/hero'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HeroController::index
 * @see app/Http/Controllers/Admin/HeroController.php:19
 * @route '/admin/hero'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\HeroController::index
 * @see app/Http/Controllers/Admin/HeroController.php:19
 * @route '/admin/hero'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\HeroController::index
 * @see app/Http/Controllers/Admin/HeroController.php:19
 * @route '/admin/hero'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\HeroController::index
 * @see app/Http/Controllers/Admin/HeroController.php:19
 * @route '/admin/hero'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\HeroController::index
 * @see app/Http/Controllers/Admin/HeroController.php:19
 * @route '/admin/hero'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\HeroController::updateContent
 * @see app/Http/Controllers/Admin/HeroController.php:42
 * @route '/admin/hero'
 */
export const updateContent = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateContent.url(options),
    method: 'put',
})

updateContent.definition = {
    methods: ["put"],
    url: '/admin/hero',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\HeroController::updateContent
 * @see app/Http/Controllers/Admin/HeroController.php:42
 * @route '/admin/hero'
 */
updateContent.url = (options?: RouteQueryOptions) => {
    return updateContent.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HeroController::updateContent
 * @see app/Http/Controllers/Admin/HeroController.php:42
 * @route '/admin/hero'
 */
updateContent.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateContent.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\HeroController::updateContent
 * @see app/Http/Controllers/Admin/HeroController.php:42
 * @route '/admin/hero'
 */
    const updateContentForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateContent.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\HeroController::updateContent
 * @see app/Http/Controllers/Admin/HeroController.php:42
 * @route '/admin/hero'
 */
        updateContentForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateContent.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateContent.form = updateContentForm
/**
* @see \App\Http\Controllers\Admin\HeroController::storeRole
 * @see app/Http/Controllers/Admin/HeroController.php:54
 * @route '/admin/hero/roles'
 */
export const storeRole = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeRole.url(options),
    method: 'post',
})

storeRole.definition = {
    methods: ["post"],
    url: '/admin/hero/roles',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\HeroController::storeRole
 * @see app/Http/Controllers/Admin/HeroController.php:54
 * @route '/admin/hero/roles'
 */
storeRole.url = (options?: RouteQueryOptions) => {
    return storeRole.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HeroController::storeRole
 * @see app/Http/Controllers/Admin/HeroController.php:54
 * @route '/admin/hero/roles'
 */
storeRole.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeRole.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\HeroController::storeRole
 * @see app/Http/Controllers/Admin/HeroController.php:54
 * @route '/admin/hero/roles'
 */
    const storeRoleForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeRole.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\HeroController::storeRole
 * @see app/Http/Controllers/Admin/HeroController.php:54
 * @route '/admin/hero/roles'
 */
        storeRoleForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeRole.url(options),
            method: 'post',
        })
    
    storeRole.form = storeRoleForm
/**
* @see \App\Http\Controllers\Admin\HeroController::updateRole
 * @see app/Http/Controllers/Admin/HeroController.php:73
 * @route '/admin/hero/roles/{role}'
 */
export const updateRole = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateRole.url(args, options),
    method: 'put',
})

updateRole.definition = {
    methods: ["put"],
    url: '/admin/hero/roles/{role}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\HeroController::updateRole
 * @see app/Http/Controllers/Admin/HeroController.php:73
 * @route '/admin/hero/roles/{role}'
 */
updateRole.url = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { role: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { role: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    role: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        role: typeof args.role === 'object'
                ? args.role.id
                : args.role,
                }

    return updateRole.definition.url
            .replace('{role}', parsedArgs.role.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HeroController::updateRole
 * @see app/Http/Controllers/Admin/HeroController.php:73
 * @route '/admin/hero/roles/{role}'
 */
updateRole.put = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateRole.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\HeroController::updateRole
 * @see app/Http/Controllers/Admin/HeroController.php:73
 * @route '/admin/hero/roles/{role}'
 */
    const updateRoleForm = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateRole.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\HeroController::updateRole
 * @see app/Http/Controllers/Admin/HeroController.php:73
 * @route '/admin/hero/roles/{role}'
 */
        updateRoleForm.put = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateRole.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateRole.form = updateRoleForm
/**
* @see \App\Http\Controllers\Admin\HeroController::destroyRole
 * @see app/Http/Controllers/Admin/HeroController.php:84
 * @route '/admin/hero/roles/{role}'
 */
export const destroyRole = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyRole.url(args, options),
    method: 'delete',
})

destroyRole.definition = {
    methods: ["delete"],
    url: '/admin/hero/roles/{role}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\HeroController::destroyRole
 * @see app/Http/Controllers/Admin/HeroController.php:84
 * @route '/admin/hero/roles/{role}'
 */
destroyRole.url = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { role: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { role: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    role: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        role: typeof args.role === 'object'
                ? args.role.id
                : args.role,
                }

    return destroyRole.definition.url
            .replace('{role}', parsedArgs.role.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HeroController::destroyRole
 * @see app/Http/Controllers/Admin/HeroController.php:84
 * @route '/admin/hero/roles/{role}'
 */
destroyRole.delete = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyRole.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\HeroController::destroyRole
 * @see app/Http/Controllers/Admin/HeroController.php:84
 * @route '/admin/hero/roles/{role}'
 */
    const destroyRoleForm = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyRole.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\HeroController::destroyRole
 * @see app/Http/Controllers/Admin/HeroController.php:84
 * @route '/admin/hero/roles/{role}'
 */
        destroyRoleForm.delete = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyRole.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyRole.form = destroyRoleForm
/**
* @see \App\Http\Controllers\Admin\HeroController::reorderRoles
 * @see app/Http/Controllers/Admin/HeroController.php:95
 * @route '/admin/hero/roles/reorder'
 */
export const reorderRoles = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorderRoles.url(options),
    method: 'post',
})

reorderRoles.definition = {
    methods: ["post"],
    url: '/admin/hero/roles/reorder',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\HeroController::reorderRoles
 * @see app/Http/Controllers/Admin/HeroController.php:95
 * @route '/admin/hero/roles/reorder'
 */
reorderRoles.url = (options?: RouteQueryOptions) => {
    return reorderRoles.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HeroController::reorderRoles
 * @see app/Http/Controllers/Admin/HeroController.php:95
 * @route '/admin/hero/roles/reorder'
 */
reorderRoles.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorderRoles.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\HeroController::reorderRoles
 * @see app/Http/Controllers/Admin/HeroController.php:95
 * @route '/admin/hero/roles/reorder'
 */
    const reorderRolesForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reorderRoles.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\HeroController::reorderRoles
 * @see app/Http/Controllers/Admin/HeroController.php:95
 * @route '/admin/hero/roles/reorder'
 */
        reorderRolesForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reorderRoles.url(options),
            method: 'post',
        })
    
    reorderRoles.form = reorderRolesForm
const HeroController = { index, updateContent, storeRole, updateRole, destroyRole, reorderRoles }

export default HeroController