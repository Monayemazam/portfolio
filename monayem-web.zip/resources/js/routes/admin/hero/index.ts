import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import roles from './roles'
/**
* @see \App\Http\Controllers\Admin\HeroController::index
 * @see app/Http/Controllers/Admin/HeroController.php:19
 * @route '/admin/hero'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/hero',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\HeroController::index
 * @see app/Http/Controllers/Admin/HeroController.php:19
 * @route '/admin/hero'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HeroController::index
 * @see app/Http/Controllers/Admin/HeroController.php:19
 * @route '/admin/hero'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\HeroController::index
 * @see app/Http/Controllers/Admin/HeroController.php:19
 * @route '/admin/hero'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\HeroController::index
 * @see app/Http/Controllers/Admin/HeroController.php:19
 * @route '/admin/hero'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\HeroController::index
 * @see app/Http/Controllers/Admin/HeroController.php:19
 * @route '/admin/hero'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\HeroController::index
 * @see app/Http/Controllers/Admin/HeroController.php:19
 * @route '/admin/hero'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\HeroController::update
 * @see app/Http/Controllers/Admin/HeroController.php:42
 * @route '/admin/hero'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/hero',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\HeroController::update
 * @see app/Http/Controllers/Admin/HeroController.php:42
 * @route '/admin/hero'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HeroController::update
 * @see app/Http/Controllers/Admin/HeroController.php:42
 * @route '/admin/hero'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\HeroController::update
 * @see app/Http/Controllers/Admin/HeroController.php:42
 * @route '/admin/hero'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\HeroController::update
 * @see app/Http/Controllers/Admin/HeroController.php:42
 * @route '/admin/hero'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const hero = {
    index: Object.assign(index, index),
update: Object.assign(update, update),
roles: Object.assign(roles, roles),
}

export default hero