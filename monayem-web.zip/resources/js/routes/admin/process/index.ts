import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\ProcessStepController::reorder
 * @see app/Http/Controllers/Admin/ProcessStepController.php:82
 * @route '/admin/process/reorder'
 */
export const reorder = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorder.url(options),
    method: 'post',
})

reorder.definition = {
    methods: ["post"],
    url: '/admin/process/reorder',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\ProcessStepController::reorder
 * @see app/Http/Controllers/Admin/ProcessStepController.php:82
 * @route '/admin/process/reorder'
 */
reorder.url = (options?: RouteQueryOptions) => {
    return reorder.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProcessStepController::reorder
 * @see app/Http/Controllers/Admin/ProcessStepController.php:82
 * @route '/admin/process/reorder'
 */
reorder.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorder.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\ProcessStepController::reorder
 * @see app/Http/Controllers/Admin/ProcessStepController.php:82
 * @route '/admin/process/reorder'
 */
    const reorderForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reorder.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ProcessStepController::reorder
 * @see app/Http/Controllers/Admin/ProcessStepController.php:82
 * @route '/admin/process/reorder'
 */
        reorderForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reorder.url(options),
            method: 'post',
        })
    
    reorder.form = reorderForm
/**
* @see \App\Http\Controllers\Admin\ProcessStepController::togglePublish
 * @see app/Http/Controllers/Admin/ProcessStepController.php:69
 * @route '/admin/process/{processStep}/toggle-publish'
 */
export const togglePublish = (args: { processStep: number | { id: number } } | [processStep: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: togglePublish.url(args, options),
    method: 'patch',
})

togglePublish.definition = {
    methods: ["patch"],
    url: '/admin/process/{processStep}/toggle-publish',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\ProcessStepController::togglePublish
 * @see app/Http/Controllers/Admin/ProcessStepController.php:69
 * @route '/admin/process/{processStep}/toggle-publish'
 */
togglePublish.url = (args: { processStep: number | { id: number } } | [processStep: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { processStep: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { processStep: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    processStep: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        processStep: typeof args.processStep === 'object'
                ? args.processStep.id
                : args.processStep,
                }

    return togglePublish.definition.url
            .replace('{processStep}', parsedArgs.processStep.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProcessStepController::togglePublish
 * @see app/Http/Controllers/Admin/ProcessStepController.php:69
 * @route '/admin/process/{processStep}/toggle-publish'
 */
togglePublish.patch = (args: { processStep: number | { id: number } } | [processStep: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: togglePublish.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\ProcessStepController::togglePublish
 * @see app/Http/Controllers/Admin/ProcessStepController.php:69
 * @route '/admin/process/{processStep}/toggle-publish'
 */
    const togglePublishForm = (args: { processStep: number | { id: number } } | [processStep: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: togglePublish.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ProcessStepController::togglePublish
 * @see app/Http/Controllers/Admin/ProcessStepController.php:69
 * @route '/admin/process/{processStep}/toggle-publish'
 */
        togglePublishForm.patch = (args: { processStep: number | { id: number } } | [processStep: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: togglePublish.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    togglePublish.form = togglePublishForm
/**
* @see \App\Http\Controllers\Admin\ProcessStepController::index
 * @see app/Http/Controllers/Admin/ProcessStepController.php:17
 * @route '/admin/process'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/process',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ProcessStepController::index
 * @see app/Http/Controllers/Admin/ProcessStepController.php:17
 * @route '/admin/process'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProcessStepController::index
 * @see app/Http/Controllers/Admin/ProcessStepController.php:17
 * @route '/admin/process'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ProcessStepController::index
 * @see app/Http/Controllers/Admin/ProcessStepController.php:17
 * @route '/admin/process'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ProcessStepController::index
 * @see app/Http/Controllers/Admin/ProcessStepController.php:17
 * @route '/admin/process'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ProcessStepController::index
 * @see app/Http/Controllers/Admin/ProcessStepController.php:17
 * @route '/admin/process'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ProcessStepController::index
 * @see app/Http/Controllers/Admin/ProcessStepController.php:17
 * @route '/admin/process'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\ProcessStepController::store
 * @see app/Http/Controllers/Admin/ProcessStepController.php:28
 * @route '/admin/process'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/process',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\ProcessStepController::store
 * @see app/Http/Controllers/Admin/ProcessStepController.php:28
 * @route '/admin/process'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProcessStepController::store
 * @see app/Http/Controllers/Admin/ProcessStepController.php:28
 * @route '/admin/process'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\ProcessStepController::store
 * @see app/Http/Controllers/Admin/ProcessStepController.php:28
 * @route '/admin/process'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ProcessStepController::store
 * @see app/Http/Controllers/Admin/ProcessStepController.php:28
 * @route '/admin/process'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\ProcessStepController::update
 * @see app/Http/Controllers/Admin/ProcessStepController.php:46
 * @route '/admin/process/{processStep}'
 */
export const update = (args: { processStep: number | { id: number } } | [processStep: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/process/{processStep}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\ProcessStepController::update
 * @see app/Http/Controllers/Admin/ProcessStepController.php:46
 * @route '/admin/process/{processStep}'
 */
update.url = (args: { processStep: number | { id: number } } | [processStep: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { processStep: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { processStep: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    processStep: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        processStep: typeof args.processStep === 'object'
                ? args.processStep.id
                : args.processStep,
                }

    return update.definition.url
            .replace('{processStep}', parsedArgs.processStep.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProcessStepController::update
 * @see app/Http/Controllers/Admin/ProcessStepController.php:46
 * @route '/admin/process/{processStep}'
 */
update.put = (args: { processStep: number | { id: number } } | [processStep: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\ProcessStepController::update
 * @see app/Http/Controllers/Admin/ProcessStepController.php:46
 * @route '/admin/process/{processStep}'
 */
update.patch = (args: { processStep: number | { id: number } } | [processStep: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\ProcessStepController::update
 * @see app/Http/Controllers/Admin/ProcessStepController.php:46
 * @route '/admin/process/{processStep}'
 */
    const updateForm = (args: { processStep: number | { id: number } } | [processStep: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ProcessStepController::update
 * @see app/Http/Controllers/Admin/ProcessStepController.php:46
 * @route '/admin/process/{processStep}'
 */
        updateForm.put = (args: { processStep: number | { id: number } } | [processStep: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\ProcessStepController::update
 * @see app/Http/Controllers/Admin/ProcessStepController.php:46
 * @route '/admin/process/{processStep}'
 */
        updateForm.patch = (args: { processStep: number | { id: number } } | [processStep: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\ProcessStepController::destroy
 * @see app/Http/Controllers/Admin/ProcessStepController.php:57
 * @route '/admin/process/{processStep}'
 */
export const destroy = (args: { processStep: number | { id: number } } | [processStep: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/process/{processStep}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\ProcessStepController::destroy
 * @see app/Http/Controllers/Admin/ProcessStepController.php:57
 * @route '/admin/process/{processStep}'
 */
destroy.url = (args: { processStep: number | { id: number } } | [processStep: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { processStep: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { processStep: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    processStep: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        processStep: typeof args.processStep === 'object'
                ? args.processStep.id
                : args.processStep,
                }

    return destroy.definition.url
            .replace('{processStep}', parsedArgs.processStep.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProcessStepController::destroy
 * @see app/Http/Controllers/Admin/ProcessStepController.php:57
 * @route '/admin/process/{processStep}'
 */
destroy.delete = (args: { processStep: number | { id: number } } | [processStep: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\ProcessStepController::destroy
 * @see app/Http/Controllers/Admin/ProcessStepController.php:57
 * @route '/admin/process/{processStep}'
 */
    const destroyForm = (args: { processStep: number | { id: number } } | [processStep: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ProcessStepController::destroy
 * @see app/Http/Controllers/Admin/ProcessStepController.php:57
 * @route '/admin/process/{processStep}'
 */
        destroyForm.delete = (args: { processStep: number | { id: number } } | [processStep: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const process = {
    reorder: Object.assign(reorder, reorder),
togglePublish: Object.assign(togglePublish, togglePublish),
index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default process