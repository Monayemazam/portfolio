import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AboutController::store
 * @see app/Http/Controllers/Admin/AboutController.php:60
 * @route '/admin/about/facts'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/about/facts',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AboutController::store
 * @see app/Http/Controllers/Admin/AboutController.php:60
 * @route '/admin/about/facts'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AboutController::store
 * @see app/Http/Controllers/Admin/AboutController.php:60
 * @route '/admin/about/facts'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AboutController::store
 * @see app/Http/Controllers/Admin/AboutController.php:60
 * @route '/admin/about/facts'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AboutController::store
 * @see app/Http/Controllers/Admin/AboutController.php:60
 * @route '/admin/about/facts'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\AboutController::update
 * @see app/Http/Controllers/Admin/AboutController.php:79
 * @route '/admin/about/facts/{fact}'
 */
export const update = (args: { fact: number | { id: number } } | [fact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/about/facts/{fact}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\AboutController::update
 * @see app/Http/Controllers/Admin/AboutController.php:79
 * @route '/admin/about/facts/{fact}'
 */
update.url = (args: { fact: number | { id: number } } | [fact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fact: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fact: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fact: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fact: typeof args.fact === 'object'
                ? args.fact.id
                : args.fact,
                }

    return update.definition.url
            .replace('{fact}', parsedArgs.fact.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AboutController::update
 * @see app/Http/Controllers/Admin/AboutController.php:79
 * @route '/admin/about/facts/{fact}'
 */
update.put = (args: { fact: number | { id: number } } | [fact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\AboutController::update
 * @see app/Http/Controllers/Admin/AboutController.php:79
 * @route '/admin/about/facts/{fact}'
 */
    const updateForm = (args: { fact: number | { id: number } } | [fact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AboutController::update
 * @see app/Http/Controllers/Admin/AboutController.php:79
 * @route '/admin/about/facts/{fact}'
 */
        updateForm.put = (args: { fact: number | { id: number } } | [fact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\AboutController::destroy
 * @see app/Http/Controllers/Admin/AboutController.php:90
 * @route '/admin/about/facts/{fact}'
 */
export const destroy = (args: { fact: number | { id: number } } | [fact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/about/facts/{fact}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\AboutController::destroy
 * @see app/Http/Controllers/Admin/AboutController.php:90
 * @route '/admin/about/facts/{fact}'
 */
destroy.url = (args: { fact: number | { id: number } } | [fact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fact: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fact: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fact: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fact: typeof args.fact === 'object'
                ? args.fact.id
                : args.fact,
                }

    return destroy.definition.url
            .replace('{fact}', parsedArgs.fact.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AboutController::destroy
 * @see app/Http/Controllers/Admin/AboutController.php:90
 * @route '/admin/about/facts/{fact}'
 */
destroy.delete = (args: { fact: number | { id: number } } | [fact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\AboutController::destroy
 * @see app/Http/Controllers/Admin/AboutController.php:90
 * @route '/admin/about/facts/{fact}'
 */
    const destroyForm = (args: { fact: number | { id: number } } | [fact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AboutController::destroy
 * @see app/Http/Controllers/Admin/AboutController.php:90
 * @route '/admin/about/facts/{fact}'
 */
        destroyForm.delete = (args: { fact: number | { id: number } } | [fact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Admin\AboutController::reorder
 * @see app/Http/Controllers/Admin/AboutController.php:101
 * @route '/admin/about/facts/reorder'
 */
export const reorder = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorder.url(options),
    method: 'post',
})

reorder.definition = {
    methods: ["post"],
    url: '/admin/about/facts/reorder',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AboutController::reorder
 * @see app/Http/Controllers/Admin/AboutController.php:101
 * @route '/admin/about/facts/reorder'
 */
reorder.url = (options?: RouteQueryOptions) => {
    return reorder.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AboutController::reorder
 * @see app/Http/Controllers/Admin/AboutController.php:101
 * @route '/admin/about/facts/reorder'
 */
reorder.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorder.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AboutController::reorder
 * @see app/Http/Controllers/Admin/AboutController.php:101
 * @route '/admin/about/facts/reorder'
 */
    const reorderForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reorder.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AboutController::reorder
 * @see app/Http/Controllers/Admin/AboutController.php:101
 * @route '/admin/about/facts/reorder'
 */
        reorderForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reorder.url(options),
            method: 'post',
        })
    
    reorder.form = reorderForm
const facts = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
reorder: Object.assign(reorder, reorder),
}

export default facts